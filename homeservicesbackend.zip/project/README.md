# Home Services Booking Backend

This project is a Spring Boot backend application for a home services booking platform. It provides a comprehensive REST API for managing service categories, services, bookings, payments, and reviews.

## Features

* User authentication and authorization using JWT
* Service category management
* Service listing and management
* Booking system
* Payment processing
* Review and rating system
* Role-based access control (User, Service Provider, Admin)

## Technologies Used

* Java 17
* Spring Boot 3.2.0
* Spring Data JPA
* Spring Security
* MySQL Database
* Lombok
* JWT Authentication
* OpenAPI/Swagger Documentation

## Prerequisites

* Java 17 or later
* Maven
* MySQL Server

## Setup and Installation

1. **Clone the repository**

```bash
git clone <repository-url>
cd booking-backend
```

2. **Configure database**

Update the `application.properties` file with your MySQL credentials:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/homeservices?createDatabaseIfNotExist=true
spring.datasource.username=your-username
spring.datasource.password=your-password
```

3. **Build the project**

```bash
mvn clean install
```

4. **Run the application**

```bash
mvn spring-boot:run
```

## API Documentation

When the application is running, you can access the API documentation at:

```
http://localhost:8080/api/swagger-ui/index.html
```

## API Endpoints

The application provides the following main endpoints:

### Authentication
- `POST /api/auth/signup`: Register a new user
- `POST /api/auth/signin`: Login and get JWT token

### Categories
- `GET /api/categories`: Get all categories
- `GET /api/categories/{id}`: Get category by ID
- `POST /api/categories`: Create a new category (admin only)
- `PUT /api/categories/{id}`: Update a category (admin only)
- `DELETE /api/categories/{id}`: Delete a category (admin only)

### Services
- `GET /api/services`: Get all services
- `GET /api/services/{id}`: Get service by ID
- `GET /api/services/category/{categoryId}`: Get services by category
- `POST /api/services`: Create a new service (admin/provider only)
- `PUT /api/services/{id}`: Update a service (admin/provider only)
- `DELETE /api/services/{id}`: Delete a service (admin/provider only)

### Bookings
- `GET /api/bookings`: Get current user's bookings
- `GET /api/bookings/all`: Get all bookings (admin/provider only)
- `GET /api/bookings/{id}`: Get booking by ID
- `POST /api/bookings`: Create a new booking
- `PUT /api/bookings/{id}/status`: Update booking status (admin/provider only)
- `DELETE /api/bookings/{id}`: Cancel a booking

### Payments
- `GET /api/payments`: Get current user's payments
- `GET /api/payments/all`: Get all payments (admin only)
- `GET /api/payments/{id}`: Get payment by ID
- `GET /api/payments/booking/{bookingId}`: Get payment by booking ID
- `POST /api/payments`: Process a payment
- `PUT /api/payments/{id}/status`: Update payment status (admin only)

### Reviews
- `GET /api/reviews`: Get all reviews
- `GET /api/reviews/service/{serviceId}`: Get reviews by service
- `GET /api/reviews/user`: Get current user's reviews
- `POST /api/reviews`: Create a new review
- `PUT /api/reviews/{id}`: Update a review
- `DELETE /api/reviews/{id}`: Delete a review

## Postman Collection

A Postman collection is included in the project under the `postman` directory. You can import this collection to test the API endpoints.

## Security

The application uses JWT for authentication and authorization. When a user logs in, they receive a JWT token that should be included in the `Authorization` header for subsequent requests:

```
Authorization: Bearer <jwt-token>
```

## Database Schema

The application uses the following main entities:

* User
* ServiceCategory
* Service
* Booking
* Payment
* Review

Relationships:
* A user can make multiple bookings
* A service belongs to one category
* A category can have multiple services
* A booking is for one service by one user
* A payment is linked to one booking
* A review is created by one user for one service

## License

This project is licensed under the MIT License.