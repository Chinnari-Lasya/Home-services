package com.homeservices.service;

import com.homeservices.dto.ReviewRequest;
import com.homeservices.model.Review;
import com.homeservices.model.Service;
import com.homeservices.model.User;
import com.homeservices.repository.ReviewRepository;
import com.homeservices.repository.ServiceRepository;
import com.homeservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final ServiceRepository serviceRepository;

    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    public List<Review> getReviewsByServiceId(Long serviceId) {
        return reviewRepository.findByServiceId(serviceId);
    }

    public List<Review> getReviewsByUserId(Long userId) {
        return reviewRepository.findByUserId(userId);
    }

    @Transactional
    public Review createReview(ReviewRequest reviewRequest, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        Service service = serviceRepository.findById(reviewRequest.getServiceId())
                .orElseThrow(() -> new RuntimeException("Service not found"));
        
        Review review = new Review();
        review.setUser(user);
        review.setService(service);
        review.setRating(reviewRequest.getRating());
        review.setComment(reviewRequest.getComment());
        
        return reviewRepository.save(review);
    }

    @Transactional
    public Optional<Review> updateReview(Long id, ReviewRequest reviewRequest, Long userId) {
        return reviewRepository.findById(id)
                .filter(review -> review.getUser().getId().equals(userId))
                .map(review -> {
                    if (reviewRequest.getServiceId() != null && 
                        !reviewRequest.getServiceId().equals(review.getService().getId())) {
                        
                        Service service = serviceRepository.findById(reviewRequest.getServiceId())
                                .orElseThrow(() -> new RuntimeException("Service not found"));
                        review.setService(service);
                    }
                    
                    review.setRating(reviewRequest.getRating());
                    review.setComment(reviewRequest.getComment());
                    return reviewRepository.save(review);
                });
    }

    @Transactional
    public boolean deleteReview(Long id, Long userId) {
        Optional<Review> review = reviewRepository.findById(id);
        
        // User can delete their own reviews, admin can delete any review
        return review.filter(r -> r.getUser().getId().equals(userId) || 
                          userRepository.findById(userId)
                                      .map(user -> user.getRole() == User.Role.ROLE_ADMIN)
                                      .orElse(false))
                .map(r -> {
                    reviewRepository.delete(r);
                    return true;
                })
                .orElse(false);
    }
}