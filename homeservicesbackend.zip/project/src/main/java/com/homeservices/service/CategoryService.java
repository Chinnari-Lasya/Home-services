package com.homeservices.service;

import com.homeservices.model.ServiceCategory;
import com.homeservices.repository.ServiceCategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CategoryService {

    private final ServiceCategoryRepository categoryRepository;

    public List<ServiceCategory> getAllCategories() {
        return categoryRepository.findAll();
    }

    public Optional<ServiceCategory> getCategoryById(Long id) {
        return categoryRepository.findById(id);
    }

    public ServiceCategory createCategory(ServiceCategory category) {
        return categoryRepository.save(category);
    }

    public Optional<ServiceCategory> updateCategory(Long id, ServiceCategory categoryDetails) {
        return categoryRepository.findById(id)
                .map(category -> {
                    category.setName(categoryDetails.getName());
                    category.setDescription(categoryDetails.getDescription());
                    category.setImageUrl(categoryDetails.getImageUrl());
                    return categoryRepository.save(category);
                });
    }

    public boolean deleteCategory(Long id) {
        return categoryRepository.findById(id)
                .map(category -> {
                    categoryRepository.delete(category);
                    return true;
                })
                .orElse(false);
    }
}