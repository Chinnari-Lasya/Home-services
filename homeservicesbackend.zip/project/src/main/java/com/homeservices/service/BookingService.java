package com.homeservices.service;

import com.homeservices.dto.BookingRequest;
import com.homeservices.model.Booking;
import com.homeservices.model.Service;
import com.homeservices.model.User;
import com.homeservices.repository.BookingRepository;
import com.homeservices.repository.ServiceRepository;
import com.homeservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final ServiceRepository serviceRepository;

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Optional<Booking> getBookingById(Long id, Long userId) {
        Optional<Booking> booking = bookingRepository.findById(id);
        // Users can only see their own bookings, admins can see all
        return booking.filter(b -> b.getUser().getId().equals(userId) || 
                          userRepository.findById(userId)
                                      .map(user -> user.getRole() == User.Role.ROLE_ADMIN || 
                                                  user.getRole() == User.Role.ROLE_SERVICE_PROVIDER)
                                      .orElse(false));
    }

    public List<Booking> getBookingsByUserId(Long userId) {
        return bookingRepository.findByUserId(userId);
    }

    @Transactional
    public Booking createBooking(BookingRequest bookingRequest, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        Service service = serviceRepository.findById(bookingRequest.getServiceId())
                .orElseThrow(() -> new RuntimeException("Service not found"));
        
        Booking booking = new Booking();
        booking.setUser(user);
        booking.setService(service);
        booking.setBookingDateTime(bookingRequest.getBookingDateTime());
        booking.setAddress(bookingRequest.getAddress());
        booking.setSpecialInstructions(bookingRequest.getSpecialInstructions());
        booking.setStatus(Booking.BookingStatus.PENDING);
        
        return bookingRepository.save(booking);
    }

    @Transactional
    public Optional<Booking> updateBookingStatus(Long id, Booking.BookingStatus status) {
        return bookingRepository.findById(id)
                .map(booking -> {
                    booking.setStatus(status);
                    return bookingRepository.save(booking);
                });
    }

    @Transactional
    public boolean cancelBooking(Long id, Long userId) {
        Optional<Booking> booking = bookingRepository.findById(id);
        
        return booking.filter(b -> b.getUser().getId().equals(userId) || 
                          userRepository.findById(userId)
                                      .map(user -> user.getRole() == User.Role.ROLE_ADMIN)
                                      .orElse(false))
                .map(b -> {
                    if (b.getStatus() != Booking.BookingStatus.COMPLETED) {
                        b.setStatus(Booking.BookingStatus.CANCELLED);
                        bookingRepository.save(b);
                        return true;
                    }
                    return false;
                })
                .orElse(false);
    }
}