package com.homeservices.service;

import com.homeservices.dto.PaymentRequest;
import com.homeservices.model.Booking;
import com.homeservices.model.Payment;
import com.homeservices.model.User;
import com.homeservices.repository.BookingRepository;
import com.homeservices.repository.PaymentRepository;
import com.homeservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public List<Payment> getPaymentsByUserId(Long userId) {
        // Get all bookings for the user first
        List<Booking> userBookings = bookingRepository.findByUserId(userId);
        
        // Extract booking IDs
        List<Long> bookingIds = userBookings.stream()
                .map(Booking::getId)
                .collect(Collectors.toList());
        
        // Filter payments by those booking IDs
        return paymentRepository.findAll().stream()
                .filter(payment -> bookingIds.contains(payment.getBooking().getId()))
                .collect(Collectors.toList());
    }

    public Optional<Payment> getPaymentById(Long id, Long userId) {
        Optional<Payment> payment = paymentRepository.findById(id);
        
        // Users can only see their own payments, admins can see all
        return payment.filter(p -> p.getBooking().getUser().getId().equals(userId) || 
                         userRepository.findById(userId)
                                     .map(user -> user.getRole() == User.Role.ROLE_ADMIN)
                                     .orElse(false));
    }

    public Optional<Payment> getPaymentByBookingId(Long bookingId, Long userId) {
        Optional<Booking> booking = bookingRepository.findById(bookingId);
        
        // Verify that the booking belongs to the user or the user is an admin
        if (booking.isPresent() && 
            (booking.get().getUser().getId().equals(userId) || 
             userRepository.findById(userId)
                         .map(user -> user.getRole() == User.Role.ROLE_ADMIN)
                         .orElse(false))) {
            return paymentRepository.findByBookingId(bookingId);
        }
        
        return Optional.empty();
    }

    @Transactional
    public Payment processPayment(PaymentRequest paymentRequest, Long userId) {
        Booking booking = bookingRepository.findById(paymentRequest.getBookingId())
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        
        // Verify that the booking belongs to the user
        if (!booking.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized to make payment for this booking");
        }
        
        // Check for existing payment
        Optional<Payment> existingPayment = paymentRepository.findByBookingId(booking.getId());
        if (existingPayment.isPresent()) {
            throw new RuntimeException("Payment already exists for this booking");
        }
        
        // Process payment logic here (would normally include payment gateway integration)
        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setAmount(booking.getService().getPrice());
        payment.setPaymentMethod(paymentRequest.getPaymentMethod());
        payment.setStatus(Payment.PaymentStatus.COMPLETED); // Simulate successful payment
        payment.setTransactionId(UUID.randomUUID().toString());
        
        // Update booking status
        booking.setStatus(Booking.BookingStatus.CONFIRMED);
        bookingRepository.save(booking);
        
        return paymentRepository.save(payment);
    }

    @Transactional
    public Optional<Payment> updatePaymentStatus(Long id, Payment.PaymentStatus status) {
        return paymentRepository.findById(id)
                .map(payment -> {
                    payment.setStatus(status);
                    
                    // Update booking status based on payment status
                    if (status == Payment.PaymentStatus.COMPLETED) {
                        Booking booking = payment.getBooking();
                        booking.setStatus(Booking.BookingStatus.CONFIRMED);
                        bookingRepository.save(booking);
                    } else if (status == Payment.PaymentStatus.FAILED || status == Payment.PaymentStatus.REFUNDED) {
                        Booking booking = payment.getBooking();
                        booking.setStatus(Booking.BookingStatus.CANCELLED);
                        bookingRepository.save(booking);
                    }
                    
                    return paymentRepository.save(payment);
                });
    }
}