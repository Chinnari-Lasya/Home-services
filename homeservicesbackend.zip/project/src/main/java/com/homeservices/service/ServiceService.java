package com.homeservices.service;

import com.homeservices.dto.ServiceDTO;
import com.homeservices.model.Service;
import com.homeservices.model.ServiceCategory;
import com.homeservices.repository.ReviewRepository;
import com.homeservices.repository.ServiceCategoryRepository;
import com.homeservices.repository.ServiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ServiceService {

    private final ServiceRepository serviceRepository;
    private final ServiceCategoryRepository categoryRepository;
    private final ReviewRepository reviewRepository;

    public List<ServiceDTO> getAllServices() {
        return serviceRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public Optional<ServiceDTO> getServiceById(Long id) {
        return serviceRepository.findById(id)
                .map(this::convertToDTO);
    }

    public List<ServiceDTO> getServicesByCategory(Long categoryId) {
        return serviceRepository.findByCategoryId(categoryId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public ServiceDTO createService(ServiceDTO serviceDTO) {
        Service service = convertToEntity(serviceDTO);
        Service savedService = serviceRepository.save(service);
        return convertToDTO(savedService);
    }

    @Transactional
    public Optional<ServiceDTO> updateService(Long id, ServiceDTO serviceDTO) {
        return serviceRepository.findById(id)
                .map(service -> {
                    service.setName(serviceDTO.getName());
                    service.setDescription(serviceDTO.getDescription());
                    service.setPrice(serviceDTO.getPrice());
                    service.setDurationMinutes(serviceDTO.getDurationMinutes());
                    service.setImageUrl(serviceDTO.getImageUrl());
                    
                    if (serviceDTO.getCategoryId() != null) {
                        categoryRepository.findById(serviceDTO.getCategoryId())
                                .ifPresent(service::setCategory);
                    }
                    
                    return convertToDTO(serviceRepository.save(service));
                });
    }

    public boolean deleteService(Long id) {
        return serviceRepository.findById(id)
                .map(service -> {
                    serviceRepository.delete(service);
                    return true;
                })
                .orElse(false);
    }

    private ServiceDTO convertToDTO(Service service) {
        ServiceDTO dto = new ServiceDTO();
        dto.setId(service.getId());
        dto.setName(service.getName());
        dto.setDescription(service.getDescription());
        dto.setPrice(service.getPrice());
        dto.setDurationMinutes(service.getDurationMinutes());
        dto.setImageUrl(service.getImageUrl());
        
        if (service.getCategory() != null) {
            dto.setCategoryId(service.getCategory().getId());
            dto.setCategoryName(service.getCategory().getName());
        }
        
        // Get average rating
        Double avgRating = reviewRepository.getAverageRatingForService(service.getId());
        dto.setAverageRating(avgRating);
        
        return dto;
    }

    private Service convertToEntity(ServiceDTO dto) {
        Service service = new Service();
        service.setName(dto.getName());
        service.setDescription(dto.getDescription());
        service.setPrice(dto.getPrice());
        service.setDurationMinutes(dto.getDurationMinutes());
        service.setImageUrl(dto.getImageUrl());
        
        if (dto.getCategoryId() != null) {
            Optional<ServiceCategory> category = categoryRepository.findById(dto.getCategoryId());
            category.ifPresent(service::setCategory);
        }
        
        return service;
    }
}