package com.homeservices.controller;

import com.homeservices.dto.PaymentRequest;
import com.homeservices.model.Payment;
import com.homeservices.security.UserDetailsImpl;
import com.homeservices.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @GetMapping
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<List<Payment>> getUserPayments(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        List<Payment> payments = paymentService.getPaymentsByUserId(userDetails.getId());
        return ResponseEntity.ok(payments);
    }

    @GetMapping("/all")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<Payment>> getAllPayments() {
        List<Payment> payments = paymentService.getAllPayments();
        return ResponseEntity.ok(payments);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long id, @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return paymentService.getPaymentById(id, userDetails.getId())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/booking/{bookingId}")
    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<Payment> getPaymentByBookingId(@PathVariable Long bookingId, 
                                                      @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return paymentService.getPaymentByBookingId(bookingId, userDetails.getId())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<Payment> processPayment(@Valid @RequestBody PaymentRequest paymentRequest, 
                                                @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Payment payment = paymentService.processPayment(paymentRequest, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(payment);
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Payment> updatePaymentStatus(@PathVariable Long id, 
                                                    @RequestParam Payment.PaymentStatus status) {
        return paymentService.updatePaymentStatus(id, status)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}