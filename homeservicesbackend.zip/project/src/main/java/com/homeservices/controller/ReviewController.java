package com.homeservices.controller;

import com.homeservices.dto.ReviewRequest;
import com.homeservices.model.Review;
import com.homeservices.security.UserDetailsImpl;
import com.homeservices.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @GetMapping
    public ResponseEntity<List<Review>> getAllReviews() {
        List<Review> reviews = reviewService.getAllReviews();
        return ResponseEntity.ok(reviews);
    }

    @GetMapping("/service/{serviceId}")
    public ResponseEntity<List<Review>> getReviewsByService(@PathVariable Long serviceId) {
        List<Review> reviews = reviewService.getReviewsByServiceId(serviceId);
        return ResponseEntity.ok(reviews);
    }

    @GetMapping("/user")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<List<Review>> getUserReviews(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        List<Review> reviews = reviewService.getReviewsByUserId(userDetails.getId());
        return ResponseEntity.ok(reviews);
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<Review> createReview(@Valid @RequestBody ReviewRequest reviewRequest, 
                                             @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Review review = reviewService.createReview(reviewRequest, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(review);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<Review> updateReview(@PathVariable Long id, 
                                             @Valid @RequestBody ReviewRequest reviewRequest, 
                                             @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return reviewService.updateReview(id, reviewRequest, userDetails.getId())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> deleteReview(@PathVariable Long id, @AuthenticationPrincipal UserDetailsImpl userDetails) {
        if (reviewService.deleteReview(id, userDetails.getId())) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}