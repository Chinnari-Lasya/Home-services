package com.homeservices.controller;

import com.homeservices.dto.BookingRequest;
import com.homeservices.model.Booking;
import com.homeservices.security.UserDetailsImpl;
import com.homeservices.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @GetMapping
    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_SERVICE_PROVIDER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<Booking>> getCurrentUserBookings(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        List<Booking> bookings = bookingService.getBookingsByUserId(userDetails.getId());
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/all")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_SERVICE_PROVIDER')")
    public ResponseEntity<List<Booking>> getAllBookings() {
        List<Booking> bookings = bookingService.getAllBookings();
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_SERVICE_PROVIDER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long id, @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return bookingService.getBookingById(id, userDetails.getId())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<Booking> createBooking(@Valid @RequestBody BookingRequest bookingRequest, 
                                               @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Booking booking = bookingService.createBooking(bookingRequest, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(booking);
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_SERVICE_PROVIDER')")
    public ResponseEntity<Booking> updateBookingStatus(@PathVariable Long id, 
                                                     @RequestParam Booking.BookingStatus status) {
        return bookingService.updateBookingStatus(id, status)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> cancelBooking(@PathVariable Long id, @AuthenticationPrincipal UserDetailsImpl userDetails) {
        if (bookingService.cancelBooking(id, userDetails.getId())) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}