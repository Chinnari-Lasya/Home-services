package com.homeservices.repository;

import com.homeservices.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUserId(Long userId);
    List<Booking> findByServiceId(Long serviceId);
    List<Booking> findByBookingDateTimeBetween(LocalDateTime start, LocalDateTime end);
    List<Booking> findByStatus(Booking.BookingStatus status);
}