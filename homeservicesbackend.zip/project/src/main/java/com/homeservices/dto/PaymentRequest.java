package com.homeservices.dto;

import com.homeservices.model.Payment.PaymentMethod;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequest {
    @NotNull(message = "Booking ID is required")
    private Long bookingId;
    
    @NotNull(message = "Payment method is required")
    private PaymentMethod paymentMethod;
    
    // Credit card details if needed
    private String cardNumber;
    private String cardHolderName;
    private String expirationDate;
    private String cvv;
}